var calc = require('C:\\nodejs\\계산기\\ch02_test5-1.js');
console.log('김미나의 사칙 연산')
console.log('a + b = '+calc.add(10, 5))
console.log('a - b = '+calc.substract(10, 5))
console.log('a * b = '+calc.multiply(10, 5))
console.log('a / b = '+calc.divide(10, 5))
